function basechange(){
    let num = document.getElementById("num").value;
    let base = document.getElementById("base").value;
    let result = 0;
    let i =1 
    if (base="binary"){
        while (num!=0){
            let rem = num%2;
            num = parseInt(num/2);
            result = result + rem*i;
            i=i*10;
        }
    }else if (base="octal"){
        while (num!=0){
            let rem = num%8;
            num = parseInt(num/8);
            result = result + rem*i;
            i=i*10;
        }
    }
    if (isNaN([[result]])) {
        // Print an error on bad input
        document.getElementById("result").innerHTML = "Invalid input";
    } else {
        // Otherwise, add the result to the HTML document
        document.getElementById("result").innerHTML = result;
    }
}

document.getElementById("num").addEventListener("keyup", basechange);
document.getElementByValue("base").addEventListener("keyup", basechange);