function basechange(num,base){
    let result= num.toString(base);
    return result;
}