function colorchnage(){
    let hex = document.getElementById("hexinput").value;
    function valid(hex){
        let validPattern = /([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
        return validPattern.test(hex);
    }
    if (valid(hex) == true){
        document.getElementById("result").style.color = hex;
    } else{
        document.getElementById("result").style.color = "black";
        console.log("not a valid hex code");
    }
}