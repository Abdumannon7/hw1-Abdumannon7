// Function to get two numbers and add them together
function powerNums() {
    // Find the items in the HTML page, and get their values
    var num1 = document.getElementById("num1").value;
    var num2 = document.getElementById("num2").value;
    var power = parseInt(num1);

    // Compute these, and make sure you convert them to integers
    if (parseInt(num2)!=0){
        for (let i =1; i< parseInt(num2); i++){
        power = power * parseInt(num1);}
    } else {
        power = 1
    }
    
    

    // If we got some output that isn't a number...
    if (isNaN([[power]])) {
        // Print an error on bad input
        document.getElementById("result2").innerHTML = "Invalid input";
    } else {
        // Otherwise, add the result to the HTML document
        document.getElementById("result2").innerHTML = power;
    }
}

// Add event listeners so the functions are called whenever the input changes
document.getElementById("num1").addEventListener("keyup", powerNums);
document.getElementById("num2").addEventListener("keyup", powerNums);